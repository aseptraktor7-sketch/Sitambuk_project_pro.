package com.tambuk.sitambukproject.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.theme.NeonBlue
import com.tambuk.sitambukproject.ui.theme.RedZoneWarning

@Composable
fun VerticalBarGauge(
    icon: ImageVector,
    topLabel: String,
    bottomLabel: String,
    percentage: Float?,
    activeColor: Color = NeonBlue,
    modifier: Modifier = Modifier
) {
    val animPercent by animateFloatAsState(
        targetValue = percentage?.coerceIn(0f, 100f) ?: 0f,
        label = "BarPercentAnim"
    )

    Column(
        modifier = modifier
            .width(42.dp)
            .fillMaxHeight()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (percentage != null) activeColor else Color.Gray,
            modifier = Modifier.size(20.dp)
        )

        Text(topLabel, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Box(
            modifier = Modifier
                .width(18.dp)
                .weight(1f)
                .padding(vertical = 6.dp)
                .border(1.dp, Color(0xFF233547), RoundedCornerShape(4.dp))
                .background(Color(0xFF0A0F16)),
            contentAlignment = Alignment.BottomCenter
        ) {
            if (percentage != null) {
                val fillRatio = animPercent / 100f
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(fillRatio)
                        .background(
                            if (fillRatio < 0.15f) RedZoneWarning else activeColor,
                            RoundedCornerShape(3.dp)
                        )
                )
            } else {
                Text("--", color = Color.DarkGray, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center))
            }
        }

        Text(bottomLabel, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
