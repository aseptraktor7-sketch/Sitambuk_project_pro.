package com.tambuk.sitambukproject.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tambuk.sitambukproject.data.model.SpeedSource
import com.tambuk.sitambukproject.ui.MainViewModel
import com.tambuk.sitambukproject.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val source by viewModel.speedSource.collectAsState()
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(CarbonBlack).padding(20.dp)) {
        Row { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali", tint = NeonBlue) }; Text("PENGATURAN", color = NeonBlue, modifier = Modifier.padding(16.dp)) }
        Text("Sumber kecepatan", color = Color.White)
        listOf(SpeedSource.AUTO, SpeedSource.GPS_ONLY, SpeedSource.SENSOR_ESP32).forEach { item ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(when(item) { SpeedSource.AUTO -> "Otomatis (ESP lalu GPS)"; SpeedSource.GPS_ONLY -> "GPS saja"; else -> "Sensor/ESP" }, color = Color.White)
                RadioButton(selected = source == item, onClick = { scope.launch { viewModel.preferences.saveSpeedSource(item) } })
            }
        }
        Text("Pilih GPS untuk uji kecepatan tanpa board. Data RPM dan indikator lain tetap memerlukan sumber sensor.", color = Color.Gray)
    }
}
