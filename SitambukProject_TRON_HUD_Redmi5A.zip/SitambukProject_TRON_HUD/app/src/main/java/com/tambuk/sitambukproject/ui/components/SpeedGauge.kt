package com.tambuk.sitambukproject.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.theme.NeonBlue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedGauge(currentSpeed: Float, speedSourceLabel: String, modifier: Modifier = Modifier) {
    val maxSpeed = 160f
    val speed by animateFloatAsState(currentSpeed.coerceIn(0f, maxSpeed), tween(120), label = "speed")
    BoxWithConstraints(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f - 13f
            val start = 135f
            val sweep = 270f
            drawCircle(Color(0xFF05080D), r + 8f, c)
            drawArc(Color(0xFF14283D), start, sweep, false, style = Stroke(12f))
            drawArc(NeonBlue, start, speed / maxSpeed * sweep, false, style = Stroke(12f, cap = StrokeCap.Round))
            for (i in 0..32) {
                val a = Math.toRadians((start + i / 32f * sweep).toDouble())
                val major = i % 2 == 0
                val len = if (major) 15f else 7f
                val p1 = Offset(c.x + (r - len) * cos(a).toFloat(), c.y + (r - len) * sin(a).toFloat())
                val p2 = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                drawLine(if (major) Color.White else NeonBlue, p1, p2, if (major) 3.5f else 1.8f, StrokeCap.Round)
            }
            (0..160 step 20).forEach { v ->
                val a = Math.toRadians((start + v / maxSpeed * sweep).toDouble())
                val x = c.x + (r - 29f) * cos(a).toFloat()
                val y = c.y + (r - 29f) * sin(a).toFloat()
                drawContext.canvas.nativeCanvas.drawText(v.toString(), x, y + 5f,
                    android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.WHITE
                        textSize = (size.minDimension * 0.052f).coerceIn(11f, 22f)
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD_ITALIC)
                    })
            }
            rotate(start + speed / maxSpeed * sweep, c) {
                drawLine(Color(0xFF00BFFF), c, Offset(c.x + r - 43f, c.y), 5f, StrokeCap.Round)
            }
            drawCircle(Color(0xFF07111E), 17f, c)
            drawCircle(NeonBlue, 5f, c)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = maxWidth * 0.26f)) {
            Text(speed.toInt().toString(), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
            Text("KM/H", color = NeonBlue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(speedSourceLabel, color = Color.Gray, fontSize = 8.sp)
        }
    }
}
