package com.tambuk.sitambukproject.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.theme.NeonBlue
import com.tambuk.sitambukproject.ui.theme.RedZoneWarning
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RpmGauge(currentRpm: Float, modifier: Modifier = Modifier) {
    val rpm by animateFloatAsState(currentRpm.coerceIn(0f, 14000f), tween(120), label = "rpm")
    BoxWithConstraints(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f - 13f
            val start = 135f
            val sweep = 270f
            drawCircle(Color(0xFF05080D), r + 8f, c)
            drawArc(Color(0xFF14283D), start, sweep, false, style = Stroke(12f))
            drawArc(NeonBlue, start, (rpm / 14000f) * sweep, false, style = Stroke(12f, cap = StrokeCap.Round))
            for (i in 0..28) {
                val a = Math.toRadians((start + i / 28f * sweep).toDouble())
                val major = i % 2 == 0
                val len = if (major) 15f else 7f
                val color = if (i >= 23) RedZoneWarning else if (major) Color.White else NeonBlue
                val p1 = Offset(c.x + (r - len) * cos(a).toFloat(), c.y + (r - len) * sin(a).toFloat())
                val p2 = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                drawLine(color, p1, p2, if (major) 3.5f else 1.8f, StrokeCap.Round)
            }
            (0..14).forEach { i ->
                val a = Math.toRadians((start + i / 14f * sweep).toDouble())
                val x = c.x + (r - 29f) * cos(a).toFloat()
                val y = c.y + (r - 29f) * sin(a).toFloat()
                drawContext.canvas.nativeCanvas.drawText(i.toString(), x, y + 5f,
                    android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (i >= 11) android.graphics.Color.rgb(255,55,75) else android.graphics.Color.WHITE
                        textSize = (size.minDimension * 0.052f).coerceIn(11f, 22f)
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD_ITALIC)
                    })
            }
            rotate(start + rpm / 14000f * sweep, c) {
                drawLine(Color(0xFF00BFFF), c, Offset(c.x + r - 43f, c.y), 5f, StrokeCap.Round)
            }
            drawCircle(Color(0xFF07111E), 17f, c)
            drawCircle(NeonBlue, 5f, c)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = maxWidth * 0.27f)) {
            Text("RPM", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
            Text("×1000", color = NeonBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(String.format("%,d", rpm.toInt()), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
