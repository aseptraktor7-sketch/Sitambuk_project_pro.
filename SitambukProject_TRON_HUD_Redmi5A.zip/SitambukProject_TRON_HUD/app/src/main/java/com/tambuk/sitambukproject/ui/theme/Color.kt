package com.tambuk.sitambukproject.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonBlack = Color(0xFF070A0F)
val DarkPanelSurface = Color(0xFF101722)
val DarkPanelBorder = Color(0xFF1A2737)

val NeonBlue = Color(0xFF00E5FF)
val NeonGreen = Color(0xFF00E676)
val EngineWarningAmber = Color(0xFFFF9100)
val HighBeamBlue = Color(0xFF2979FF)
val RedZoneWarning = Color(0xFFFF1744)
