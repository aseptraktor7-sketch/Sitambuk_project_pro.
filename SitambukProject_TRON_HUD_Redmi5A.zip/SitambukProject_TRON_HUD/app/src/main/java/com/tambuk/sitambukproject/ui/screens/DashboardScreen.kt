package com.tambuk.sitambukproject.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.MainViewModel
import com.tambuk.sitambukproject.ui.components.RpmGauge
import com.tambuk.sitambukproject.ui.components.SpeedGauge
import com.tambuk.sitambukproject.ui.theme.*

private val HudBlack = Color(0xFF010309)
private val HudPanel = Color(0xE6071425)
private val HudCyan = Color(0xFF00E5FF)
private val HudBlue = Color(0xFF087BFF)
private val HudDim = Color(0xFF23445E)
private val HudGreen = Color(0xFF7CFF5B)
private val HudAmber = Color(0xFFFF7138)

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val telemetry by viewModel.telemetry.collectAsState()
    val btState by viewModel.btState.collectAsState()
    val deviceName by viewModel.connectedDeviceName.collectAsState()
    val isStale by viewModel.isDataStale.collectAsState()
    val currentTime by viewModel.currentTime.collectAsState()
    val speedSource by viewModel.speedSource.collectAsState()
    val gpsSpeed by viewModel.locationProvider.gpsSpeedKmH.collectAsState()
    val connected = btState == com.tambuk.sitambukproject.data.model.BluetoothConnectionState.CONNECTED
    val speed = when (speedSource) {
        com.tambuk.sitambukproject.data.model.SpeedSource.GPS_ONLY -> gpsSpeed
        com.tambuk.sitambukproject.data.model.SpeedSource.SENSOR_ESP32 -> telemetry.speed
        else -> if (connected && !isStale) telemetry.speed else gpsSpeed
    }
    val speedLabel = when {
        speedSource == com.tambuk.sitambukproject.data.model.SpeedSource.SENSOR_ESP32 -> "SENSOR LINK"
        connected && !isStale && speedSource == com.tambuk.sitambukproject.data.model.SpeedSource.AUTO -> "ESP LINK"
        else -> "GPS TRACK"
    }

    Box(Modifier.fillMaxSize().background(HudBlack)) {
        // Subtle technical grid and circuit traces behind the dashboard.
        Canvas(Modifier.fillMaxSize()) {
            val step = 28f
            var x = 0f
            while (x < size.width) {
                drawLine(Color(0xFF06203A).copy(alpha = 0.36f), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(Color(0xFF06203A).copy(alpha = 0.36f), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }
            // Edge rails / angled sci-fi traces.
            drawLine(HudBlue.copy(alpha = 0.8f), Offset(0f, size.height * .18f), Offset(size.width * .12f, size.height * .18f), 3f)
            drawLine(HudCyan.copy(alpha = 0.65f), Offset(size.width * .12f, size.height * .18f), Offset(size.width * .15f, size.height * .13f), 2f)
            drawLine(HudBlue.copy(alpha = 0.8f), Offset(size.width, size.height * .18f), Offset(size.width * .88f, size.height * .18f), 3f)
            drawLine(HudCyan.copy(alpha = 0.65f), Offset(size.width * .88f, size.height * .18f), Offset(size.width * .85f, size.height * .13f), 2f)
            drawLine(HudBlue.copy(alpha = 0.7f), Offset(0f, size.height * .83f), Offset(size.width * .22f, size.height * .83f), 2f)
            drawLine(HudCyan.copy(alpha = 0.7f), Offset(size.width * .78f, size.height * .83f), Offset(size.width, size.height * .83f), 2f)
        }

        Column(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top identity plate with split neon rails.
            Row(
                Modifier.fillMaxWidth().height(57.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(Modifier.weight(1f).height(2.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, HudCyan, HudBlue))))
                Column(
                    Modifier.padding(horizontal = 12.dp).clip(CutCornerShape(topStart = 3.dp, topEnd = 16.dp, bottomEnd = 3.dp, bottomStart = 16.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF10243A), Color(0xFF030812))))
                        .border(1.dp, HudCyan.copy(alpha = .95f), CutCornerShape(topStart = 3.dp, topEnd = 16.dp, bottomEnd = 3.dp, bottomStart = 16.dp))
                        .padding(horizontal = 22.dp, vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("SITAMBUK_PROJECT ⚡", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp)
                    Text("NEURAL VEHICLE INTERFACE  //  MK-I", color = HudCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.1.sp)
                }
                Box(Modifier.weight(1f).height(2.dp).background(Brush.horizontalGradient(listOf(HudBlue, HudCyan, Color.Transparent))))
            }

            Row(
                Modifier.fillMaxWidth().weight(1f).padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                // Fuel side module - no vertical bar.
                HudSidePanel(
                    modifier = Modifier.width(57.dp).fillMaxHeight(.82f),
                    title = "FUEL",
                    topContent = {
                        Icon(Icons.Default.LocalGasStation, null, tint = HudCyan, modifier = Modifier.size(25.dp))
                    },
                    centerContent = {
                        Text(telemetry.fuelPercent?.let { "${it.toInt()}%" } ?: "--%", color = if ((telemetry.fuelPercent ?: 100f) < 15f) HudAmber else HudGreen, fontSize = 15.sp, fontWeight = FontWeight.Black)
                    },
                    bottomContent = {
                        Text("F", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Box(Modifier.fillMaxWidth(.55f).height(2.dp).background(HudCyan.copy(alpha = .8f)))
                        Text("E", color = Color(0xFF8195AA), fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                )

                // Primary left instrument.
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    RpmGauge(telemetry.rpm, Modifier.fillMaxHeight().fillMaxWidth())
                    HudCornerMarks(Modifier.fillMaxSize())
                    Text("POWERTRAIN / 01", Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp), color = HudCyan.copy(alpha = .7f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }

                // Center status stack, framed like a sci-fi control module.
                Column(
                    Modifier.width(118.dp).fillMaxHeight(.9f).padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterVertically)
                ) {
                    Row(
                        Modifier.fillMaxWidth().height(43.dp).clip(CutCornerShape(8.dp))
                            .background(HudPanel).border(1.dp, HudCyan.copy(alpha = .9f), CutCornerShape(8.dp)),
                        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.BrightnessHigh, "High beam", tint = if (telemetry.highBeam) HudCyan else HudDim, modifier = Modifier.size(22.dp))
                            Text("HIGH", color = if (telemetry.highBeam) HudCyan else Color(0xFF526578), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(Modifier.width(1.dp).height(27.dp).background(HudDim))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Warning, "Check engine", tint = if (telemetry.checkEngine) HudAmber else HudDim, modifier = Modifier.size(22.dp))
                            Text("ENGINE", color = if (telemetry.checkEngine) HudAmber else Color(0xFF526578), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        Modifier.fillMaxWidth().weight(1f).clip(CutCornerShape(15.dp))
                            .background(Brush.radialGradient(listOf(Color(0xFF103D4B), Color(0xFF06101C), HudBlack)))
                            .border(2.dp, HudCyan, CutCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(Modifier.fillMaxSize()) {
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val r = size.minDimension * .42f
                            drawCircle(HudBlue.copy(alpha = .22f), r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
                            drawCircle(HudCyan.copy(alpha = .45f), r * .82f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                            for (i in 0..7) {
                                val a = Math.toRadians((i * 45.0))
                                val x1 = c.x + (r * .85f) * kotlin.math.cos(a).toFloat()
                                val y1 = c.y + (r * .85f) * kotlin.math.sin(a).toFloat()
                                val x2 = c.x + r * kotlin.math.cos(a).toFloat()
                                val y2 = c.y + r * kotlin.math.sin(a).toFloat()
                                drawLine(HudCyan, Offset(x1, y1), Offset(x2, y2), 2f)
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("GEAR", color = HudCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text(telemetry.gear.ifBlank { "N" }.uppercase(), color = HudGreen, fontSize = 47.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                            Text("TRANSMISSION", color = Color(0xFF8BA9C1), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth().height(38.dp).clip(CutCornerShape(5.dp))
                            .background(HudPanel).border(1.dp, HudBlue, CutCornerShape(5.dp)),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.BatteryChargingFull, null, tint = if (telemetry.batteryVoltage > 0f) HudCyan else HudDim, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(if (telemetry.batteryVoltage > 0f) "%.1f V".format(telemetry.batteryVoltage) else "--.- V", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        Modifier.fillMaxWidth().height(38.dp).clip(CutCornerShape(5.dp))
                            .background(HudPanel).border(1.dp, HudBlue, CutCornerShape(5.dp)),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AccessTime, null, tint = HudCyan, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(currentTime.take(5), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(4.dp))
                        Text("WIB", color = HudCyan, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Primary right instrument.
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    SpeedGauge(speed, speedLabel, Modifier.fillMaxHeight().fillMaxWidth())
                    HudCornerMarks(Modifier.fillMaxSize())
                    Text("NAV / VELOCITY", Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp), color = HudCyan.copy(alpha = .7f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }

                // Turn indicators as separate neon arrow modules.
                HudSidePanel(
                    modifier = Modifier.width(57.dp).fillMaxHeight(.82f),
                    title = "SIGNAL",
                    topContent = {
                        Icon(Icons.Default.ArrowBack, "Sein kiri", tint = if (telemetry.leftTurn) HudGreen else HudDim, modifier = Modifier.size(30.dp))
                    },
                    centerContent = {
                        Box(Modifier.fillMaxWidth(.65f).height(1.dp).background(HudCyan.copy(alpha = .65f)))
                    },
                    bottomContent = {
                        Icon(Icons.Default.ArrowForward, "Sein kanan", tint = if (telemetry.rightTurn) HudGreen else HudDim, modifier = Modifier.size(30.dp))
                    }
                )
            }

            // Bottom control deck with animated-looking segmented rails.
            Row(
                Modifier.fillMaxWidth().height(48.dp).clip(CutCornerShape(topStart = 3.dp, topEnd = 16.dp, bottomEnd = 3.dp, bottomStart = 16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF07101D), Color(0xFF0B1D31), Color(0xFF07101D))))
                    .border(1.dp, HudBlue.copy(alpha = .95f), CutCornerShape(topStart = 3.dp, topEnd = 16.dp, bottomEnd = 3.dp, bottomStart = 16.dp))
                    .padding(horizontal = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("SITAMBUK // SYSTEM ONLINE", color = HudCyan, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("RIDE  •  MONITOR  •  CONTROL", color = Color(0xFF7696B0), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.width(90.dp).height(3.dp).background(Brush.horizontalGradient(listOf(HudBlue, HudCyan, Color.Transparent))))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (connected && !isStale) "DATA LINK: ACTIVE" else "DATA LINK: STANDBY", color = if (connected && !isStale) HudGreen else HudAmber, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        Text(if (connected) (deviceName ?: "ESP LINK") else "GPS FALLBACK", color = Color(0xFF8299AE), fontSize = 7.sp)
                    }
                    Button(
                        onClick = onNavigateToSettings,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF061729), contentColor = Color.White),
                        shape = CutCornerShape(5.dp),
                        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 3.dp),
                        modifier = Modifier.height(34.dp).border(1.dp, HudCyan, CutCornerShape(5.dp))
                    ) {
                        Icon(Icons.Default.Settings, null, tint = HudCyan, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("SYSTEM", fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun HudSidePanel(
    modifier: Modifier,
    title: String,
    topContent: @Composable ColumnScope.() -> Unit,
    centerContent: @Composable ColumnScope.() -> Unit,
    bottomContent: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.clip(CutCornerShape(topStart = 4.dp, topEnd = 13.dp, bottomEnd = 4.dp, bottomStart = 13.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1B2C), Color(0xFF020711))))
            .border(1.dp, HudBlue.copy(alpha = .95f), CutCornerShape(topStart = 4.dp, topEnd = 13.dp, bottomEnd = 4.dp, bottomStart = 13.dp))
            .padding(vertical = 8.dp, horizontal = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = HudCyan, fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        topContent()
        centerContent()
        bottomContent()
    }
}

@Composable
private fun HudCornerMarks(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = HudCyan.copy(alpha = .9f)
        val l = 15f
        val w = 3f
        drawLine(c, Offset(0f, 8f), Offset(l, 8f), w)
        drawLine(c, Offset(8f, 0f), Offset(8f, l), w)
        drawLine(c, Offset(size.width - l, 8f), Offset(size.width, 8f), w)
        drawLine(c, Offset(size.width - 8f, 0f), Offset(size.width - 8f, l), w)
        drawLine(c, Offset(0f, size.height - 8f), Offset(l, size.height - 8f), w)
        drawLine(c, Offset(8f, size.height - l), Offset(8f, size.height), w)
        drawLine(c, Offset(size.width - l, size.height - 8f), Offset(size.width, size.height - 8f), w)
        drawLine(c, Offset(size.width - 8f, size.height - l), Offset(size.width - 8f, size.height), w)
    }
}

