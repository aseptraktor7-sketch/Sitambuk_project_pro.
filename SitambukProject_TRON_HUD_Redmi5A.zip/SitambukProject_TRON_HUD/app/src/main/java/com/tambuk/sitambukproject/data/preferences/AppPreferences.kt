package com.tambuk.sitambukproject.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.tambuk.sitambukproject.data.model.SpeedSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sitambuk_settings")

class AppPreferences(private val context: Context) {
    companion object {
        val KEY_MAC_ADDRESS = stringPreferencesKey("esp32_mac_address")
        val KEY_DEVICE_NAME = stringPreferencesKey("esp32_device_name")
        val KEY_SPEED_SOURCE = stringPreferencesKey("speed_source")
        val KEY_SHOW_TEMP = booleanPreferencesKey("show_temp_sensor")
    }

    val macAddress: Flow<String?> = context.dataStore.data.map { it[KEY_MAC_ADDRESS] }
    val deviceName: Flow<String?> = context.dataStore.data.map { it[KEY_DEVICE_NAME] }
    val speedSource: Flow<SpeedSource> = context.dataStore.data.map {
        when (it[KEY_SPEED_SOURCE]) {
            SpeedSource.GPS_ONLY.name -> SpeedSource.GPS_ONLY
            SpeedSource.SENSOR_ESP32.name -> SpeedSource.SENSOR_ESP32
            else -> SpeedSource.AUTO
        }
    }
    val showTempSensor: Flow<Boolean> = context.dataStore.data.map { it[KEY_SHOW_TEMP] ?: false }

    suspend fun saveDevice(address: String, name: String) {
        context.dataStore.edit {
            it[KEY_MAC_ADDRESS] = address
            it[KEY_DEVICE_NAME] = name
        }
    }

    suspend fun saveSpeedSource(source: SpeedSource) {
        context.dataStore.edit { it[KEY_SPEED_SOURCE] = source.name }
    }

    suspend fun saveShowTemp(show: Boolean) {
        context.dataStore.edit { it[KEY_SHOW_TEMP] = show }
    }
}
