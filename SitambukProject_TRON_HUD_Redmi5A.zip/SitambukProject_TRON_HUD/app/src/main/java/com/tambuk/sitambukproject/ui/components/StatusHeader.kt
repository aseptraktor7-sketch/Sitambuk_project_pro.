package com.tambuk.sitambukproject.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.data.model.BluetoothConnectionState
import com.tambuk.sitambukproject.ui.theme.*

@Composable
fun StatusHeader(
    appName: String,
    subTitle: String,
    btState: BluetoothConnectionState,
    deviceName: String?,
    isDataStale: Boolean,
    currentTime: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(appName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(subTitle, color = NeonBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }

        Text(
            text = currentTime,
            color = Color.White,
            fontSize = 20.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (isDataStale) {
                Text("TIMEOUT", color = RedZoneWarning, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            val statusColor = when (btState) {
                BluetoothConnectionState.CONNECTED -> NeonGreen
                BluetoothConnectionState.CONNECTING -> EngineWarningAmber
                BluetoothConnectionState.DISCONNECTED -> Color.Gray
            }

            val statusText = when (btState) {
                BluetoothConnectionState.CONNECTED -> deviceName ?: "TERHUBUNG"
                BluetoothConnectionState.CONNECTING -> "MENGHUBUNGKAN..."
                BluetoothConnectionState.DISCONNECTED -> "TERPUTUS"
            }

            Box(
                modifier = Modifier
                    .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null, tint = statusColor, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(statusText, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
