package com.tambuk.sitambukproject.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import com.tambuk.sitambukproject.ui.theme.*

@Composable
fun MapScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(CarbonBlack).padding(20.dp), horizontalAlignment = Alignment.Start) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali", tint = NeonBlue) }
        Text("GPS / PETA", color = NeonBlue)
        Spacer(Modifier.height(12.dp))
        Text("Layar peta dasar. Peta Google memerlukan Google Maps API key yang valid.", color = Color.White)
    }
}
