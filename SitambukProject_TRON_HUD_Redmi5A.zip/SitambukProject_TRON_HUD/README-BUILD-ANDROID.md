# Sitambuk_Project⚡

Proyek Android native Kotlin + Jetpack Compose. Build debug APK memakai JDK 17 dan Gradle 8.2+.

## Build melalui GitHub Actions (bisa dari HP)
1. Buat repository GitHub baru dan upload seluruh isi folder proyek ini (bukan file ZIP sebagai satu file).
2. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
3. Buka tab Actions, pilih `Build Sitambuk APK`, lalu tekan `Run workflow`.
4. Setelah proses hijau/sukses, buka hasil run dan unduh artifact `SitambukProject-debug-apk`.
5. Ekstrak ZIP artifact untuk mengambil `app-debug.apk`, lalu instal di Android.

Catatan: ini APK debug untuk pengujian. Data RPM dan indikator sensor akan tetap nol/tidak akurat sebelum board mengirim baris JSON yang sesuai melalui Bluetooth serial. GPS memerlukan izin lokasi. Google Maps API key belum disediakan sehingga layar peta ini masih berupa placeholder. Temperatur mesin tidak ditampilkan pada dashboard.


## Layout target and display notes

- Dashboard orientation is landscape.
- MainActivity uses immersive fullscreen mode (status and navigation bars hidden; swipe from an edge can temporarily reveal system bars).
- The layout uses density-independent Compose dimensions and adapts to the available Android window rather than assuming a fixed 2400x1080 pixel canvas.
- Xiaomi Redmi 5A's official panel resolution is 1280x720 pixels (landscape: 720x1280 orientation rotated), not 2400x1080. The UI should therefore be judged on the actual device window size.
- Temperature UI and vertical gauge bars are not displayed.
- Build/test status: source files updated; APK build and on-device layout test have not been run in this environment.
